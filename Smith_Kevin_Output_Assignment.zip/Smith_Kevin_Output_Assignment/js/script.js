/**
 *  Kevin Smith
 *  3/5/15.
 *  Scalable Data Infrastructures
 *  Output_Assignment
 */


var mySport = "Soccer";

var myStreetNumber = 2816;

var isMale = true;


console.log("My favorite sport is " + mySport + ".");

console.log("I live at " + myStreetNumber + " Clearview Ave.");

console.log("It is " + isMale + " Kevin is a male.");


